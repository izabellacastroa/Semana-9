﻿using System;

public class RuletaSimulator
{
    private Random random;

    public RuletaSimulator()
    {
        random = new Random();
    }

    public void SimularJuego(int numJugadores)
    {
        for (int i = 0; i < numJugadores; i++)
        {
            int girarResultado = GirarRuleta();
            Console.WriteLine("Resultado de giro: " + girarResultado);

            int numeroJugador = random.Next(0, 37);
            string colorJugador = (numeroJugador % 2 == 0) ? "Rojo" : "Negro";
            string paridadJugador = (numeroJugador % 2 == 0) ? "Par" : "Impar";

            Console.WriteLine("Numero del jugador: " + numeroJugador);
            Console.WriteLine("Color del jugador: " + numeroJugador);
            Console.WriteLine("Paridad del jugador: " + paridadJugador);

            if (girarResultado == numeroJugador)
            {
                Console.WriteLine("Felicidades,ha ganado");
            }
            else if ((girarResultado % 2 == 0 && paridadJugador == "Par") || (girarResultado % 2 != 0 && paridadJugador == "Impar"))
            {
                Console.WriteLine("Felicidades, ha ganado");
            }
            else if ((girarResultado % 2 == 0 && colorJugador == "Rojo") || (girarResultado % 2 != 0 && colorJugador == "Negro"))
            {
                Console.WriteLine("Felicidades, ha ganado");
            }
            else
            {
                Console.WriteLine("Lo lamento, perdió.");
            }

            Console.WriteLine();
        }
    }

    private int GirarRuleta()
    {
        return random.Next(0, 37);
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Bienvenido al juego de la ruleta");

        Console.Write("Ingresar el número de veces que desea jugar: ");
        int numJugadores = Convert.ToInt32(Console.ReadLine());

        RuletaSimulator simulator = new RuletaSimulator();
        simulator.SimularJuego(numJugadores);

        Console.WriteLine("Gracias por jugar");
    }
}
